

(function($) {

	jQuery.fn.gallerax = function(options) {
		
		var settings = jQuery.extend({
			selectorParent:		jQuery(this)
		}, options);
		
		return jQuery.gallerax(settings);
	}

	jQuery.fn.galleraxFadeOut = function(speed, callback) {
		return this.fadeTo(speed, 0.0, callback);
	}

	jQuery.fn.galleraxFadeIn = function(speed, callback) {
		return this.fadeTo(speed, 1.0, callback);
	}

	jQuery.gallerax = function(options) {

		
		
			var settings = jQuery.extend({
			
				selectorParent:						null,						
				
				
				
					outputSelector:					null,						
					outputImgSelector:				null,						
					captionSelector:				null,						
					thumbnailsSelector:				null,						
					thumbnailsImgSelector:			null,						
					navNextSelector:				null,						
					navPreviousSelector:			null,						
					navFirstSelector:				null,						
					navLastSelector:				null,						
					navStopAdvanceSelector:			null,						
					navPlayAdvanceSelector:			null,						
					
				

					categorySelector:				null,								
					categoryLines:					1,							
					
			

					captionLines:					1,							
					captionLineSeparator:			';',						
					navWrap:						true,						
					fade:							0,							
					advanceDelay:					0,							
					advanceResume:					0,							
					advanceFade:					0,							
					advanceNavActiveClass:			'active',					
					thumbnailsActiveClass:			'active',					
					thumbnailsFunction:				null,						
					thumbnailsPreloadOutput:		false						

			}, options);
			
		

			
		
				var isConfigured = true,
					isLocked = false,
					isAdvancing = false,
					cache = new Array(),
					list = new Array(),
					currentIndex = false,
					timeoutID;

			

				var __output,
					__outputImg,
					__thumbnails,
					__caption,
					__navFirst,
					__navLast,
					__navNext,
					__navPrevious,
					__navStopAdvance,
					__navPlayAdvance,
					__category;

		
			
			function cacheImage(url)
			{
				var x = document.createElement('img');
				x.src = url;
				cache.push(x);
			}
			
			function getElement(selector, required)
			{
				var x;
				
				try
				{
					if (selector == null)
						throw 'is undefined';
			
					if (settings.selectorParent)
						x = settings.selectorParent.find(selector);
					else
						x = jQuery(selector);
					
					if (x.length == 0)
						throw 'does not exist';
					
					return x;
				}
				catch (error)
				{
					if (required == true)
					{
						alert('Error: Required selector "' + selector + '" ' + error + '.');
						isConfigured = false;
					}
				}
				
				return null;
			}
			
			function advance()
			{
				if (settings.advanceDelay == 0)
					return;
			
				if (!isLocked)
					nextImage(settings.advanceFade);

				timeoutID = window.setTimeout(advance, settings.advanceDelay);
			}

			function initializeAdvance()
			{
				if (settings.advanceDelay == 0)
					return;

				if (__navPlayAdvance)
					__navPlayAdvance.addClass(settings.advanceNavActiveClass);
				
				if (__navStopAdvance)
					__navStopAdvance.removeClass(settings.advanceNavActiveClass);

				isAdvancing = true;
				timeoutID = window.setTimeout(advance, settings.advanceDelay);
			}
			
			function interruptAdvance()
			{
				if (!isAdvancing)
					return;

				if (settings.advanceDelay == 0)
					return;

				window.clearTimeout(timeoutID);

				if (settings.advanceResume == 0)
					return;

				timeoutID = window.setTimeout(advance, settings.advanceResume);
			}
			
			function stopAdvance()
			{
				if (settings.advanceDelay == 0)
					return;

				if (!isAdvancing)
					return;
			
				isAdvancing = false;
				window.clearTimeout(timeoutID);
			}
			
			function playAdvance(skip)
			{
				if (settings.advanceDelay == 0)
					return;

				if (isAdvancing)
					return;

				isAdvancing = true;

				if (skip)
					timeoutID = window.setTimeout(advance, settings.advanceDelay);
				else
					advance();
			}

			function firstImage()
			{
				switchImage(0);
			}
			
			function lastImage()
			{
				switchImage(list.length - 1);
			}

			function nextImage(speed)
			{
				if (currentIndex < list.length - 1)
					switchImage(currentIndex + 1, speed);
				else if (settings.navWrap || isAdvancing)
					switchImage(0, speed);
			}
			
			function previousImage()
			{
				if (currentIndex > 0)
					switchImage(currentIndex - 1);
				else if (settings.navWrap)
					switchImage(list.length - 1);
			}

			function switchImage(index, speed)
			{
				
				if (isLocked)
					return false;
					
				isLocked = true;

				
			
					if (!speed)
						speed = settings.fade;
				
				
				
					var newThumb = list[index];
					var oldThumb = (currentIndex !== false ? list[currentIndex] : false);
				
			
				
					var newSRC = newThumb.fullUrl;
					var oldSRC = __outputImg.attr('src');
					
				
				
					if (oldThumb)
						oldThumb.object.removeClass(settings.thumbnailsActiveClass);
					
					newThumb.object.addClass(settings.thumbnailsActiveClass);

				
				
					__outputImg.galleraxFadeOut((oldThumb !== false ? speed : 0), function() {

						

							if (__caption)
							{
								var i, s, caption;
							
								caption = unescape(newThumb.caption);
								
								if (settings.captionLines > 1)
								{
									var s = caption.split(settings.captionLineSeparator);
								
									for(i = 0; i < settings.captionLines; i++)
										__caption[i].html( (s[i] ? s[i] : '' ) );
								}
								else
									__caption.html(caption);
							}

						

							
							if (jQuery.browser.msie)
							{
								var x = __outputImg.clone(true).attr('src', newSRC).insertAfter(__outputImg);
								__outputImg.remove();
								__outputImg = x;
							}
							else
							{
								__outputImg.attr('src', '');
								__outputImg.attr('src', newSRC);
							}
					
						

							if (__outputImg.attr('complete'))
							{
								__outputImg.galleraxFadeIn(speed, function() {
									currentIndex = index;
									isLocked = false;
								});
							}

						

							else
							{
								var advanceState = isAdvancing;
								
								if (advanceState)
									stopAdvance();
							
								__outputImg.load(function() {
									__outputImg.galleraxFadeIn(speed, function() {
										currentIndex = index;
										isLocked = false;
									});
									
									if (advanceState)
										playAdvance();
									
									__outputImg.unbind('load');

								});
							}

					});
			}

			function initialize()
			{

				

					__output = getElement(settings.outputSelector, true);
					__outputImg = (settings.outputImgSelector ? __output.find(settings.outputImgSelector) : __output);

				

					__thumbnails = getElement(settings.thumbnailsSelector, true);

				

					if (settings.captionLines > 0)
					{
						if (settings.captionLines > 1)
						{
							var i, x;

							__caption = new Array();
							
							for(i = 0; i < settings.captionLines ; i++)
							{
								x = getElement(settings.captionSelector + (i > 0 ? (i + 1) : ''));
								
								if (x == null)
								{
									alert('Error: Option "captionLines" is set to "' + settings.captionLines + '", but I could not find a caption element for caption line ' + (i + 1) + '.');
									isConfigured = false;
									break;
								}
								
								__caption[i] = x;
							}
						}
						else
							__caption = getElement(settings.captionSelector);
					}
					
				

					__navFirst = getElement(settings.navFirstSelector);
					__navLast = getElement(settings.navLastSelector);
					__navNext = getElement(settings.navNextSelector);
					__navPrevious = getElement(settings.navPreviousSelector);
					__navStopAdvance = getElement(settings.navStopAdvanceSelector);
					__navPlayAdvance = getElement(settings.navPlayAdvanceSelector);

				
				
					if (isConfigured == false)
					{
						alert('Error: One or more configuration errors detected. Aborting.');
						return;
					}


			
				
						__thumbnails.each(function(index) {
							var y = jQuery(this),
								yi = (settings.thumbnailsImgSelector ? y.find(settings.thumbnailsImgSelector) : y),
								thumbUrl = yi.attr('src'),
								fullUrl = thumbUrl;

							if (settings.thumbnailsFunction)
							{
								fullUrl = settings.thumbnailsFunction(yi.attr('src'));
								
								if (fullUrl != thumbUrl
								&&	settings.thumbnailsPreloadOutput)
									cacheImage(fullUrl);
							}
							
							list[index] = {
								object:		y,
								thumbUrl:	thumbUrl,
								fullUrl:	fullUrl,
								caption:	yi.attr('title')
							};
							
							y.click(function(event) {
								event.preventDefault();
								
								if (isLocked)
									return false;
								
								if (currentIndex != index)
								{
									interruptAdvance();
									switchImage(index);
								}
							});
							
							yi.hide();
							
							if (yi.get(0).complete)
								yi.galleraxFadeIn(settings.fade);
							else
								yi.load(function() {
									jQuery(this).galleraxFadeIn(settings.fade);
									jQuery(this).unbind('load');
								});
						});

					

						if (__navNext)
							__navNext.click(function(event) {
								event.preventDefault();

								if (isLocked)
									return false;

								if (isAdvancing)
									interruptAdvance();
							
								nextImage();
							});

						if (__navPrevious)
							__navPrevious.click(function(event) {
								event.preventDefault();

								if (isLocked)
									return false;

								if (isAdvancing)
									interruptAdvance();
							
								previousImage();
							});

						if (__navFirst)
							__navFirst.click(function(event) {
								event.preventDefault();

								if (isLocked)
									return false;

								if (isAdvancing)
									interruptAdvance();
								
								firstImage();
							});

						if (__navLast)
							__navLast.click(function(event) {
								event.preventDefault();

								if (isLocked)
									return false;

								if (isAdvancing)
									interruptAdvance();

								lastImage();
							});

						if (__navStopAdvance)
							__navStopAdvance.click(function(event) {
								event.preventDefault();

								if (isLocked)
									return false;

								if (!isAdvancing)
									return false;

								__navStopAdvance.addClass(settings.advanceNavActiveClass);
								
								if (__navPlayAdvance)
									__navPlayAdvance.removeClass(settings.advanceNavActiveClass);

								stopAdvance();
							});

						if (__navPlayAdvance)
							__navPlayAdvance.click(function(event) {
								event.preventDefault();

								if (isLocked)
									return false;
									
								if (isAdvancing)
									return false;

								__navPlayAdvance.addClass(settings.advanceNavActiveClass);
								
								if (__navStopAdvance)
									__navStopAdvance.removeClass(settings.advanceNavActiveClass);
								playAdvance();
							});
			}

		

				jQuery().ready(function() {
					initialize();
					initializeAdvance();
					firstImage();
				});
	};

})(jQuery);