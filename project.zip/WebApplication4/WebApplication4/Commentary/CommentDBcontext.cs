﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WebApplication4.Commentary
{
   public class CommentDBcontext:DbContext
    {
         public CommentDBcontext(DbContextOptions<CommentDBcontext> ops):base(ops)
        {
            
        }
         public DbSet<Comments>Comment { get; set; }
    }
}
