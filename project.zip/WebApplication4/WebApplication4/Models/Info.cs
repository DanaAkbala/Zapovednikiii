﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WebApplication4.Models
{
    public class Info:DbContext
    {
        public Info(DbContextOptions<Info> ops) : base(ops)
        {

        }
        public DbSet<Ticket> Tickets { get; set; }
    }
}
